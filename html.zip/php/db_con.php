<?php
    // mysqli
    $db_host = "192.168.1.200";
    $db_user = "bambaya01";
    $db_pass = "webdbbam";
    $db_name = "webdb";
    $conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
    /*
    if (!$conn) {
        echo "<script>alert(\"DB Connection False\");</script>";
    }
    else {
        echo "<script>alert(\"DB Connection Success\");</script>";
    }
    */
?> 

