<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>PHP & MariaDB</title>
  </head>
  <body>
    <?php
      $jb_connect = mysqli_connect( '192.168.1.200', 'bambaya01', 'itbank', 'webdb' );
      if ( $jb_connect == false ) {
        echo "<p>Failure</p>";
      } else {
        echo "<p>Success</p>";
      }
    ?>
  </body>
</html>
