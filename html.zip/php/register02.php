<?php
  $username = $_POST[ 'username' ];
  $password = $_POST[ 'password' ];
  $password_confirm = $_POST[ 'password_confirm' ];
  $name=$_POST["name"];
  $phone=$_POST["phone"];
  $addr=$_POST["addr"];
  $Email=$_POST["Email"];
  if ( !is_null( $username ) ) {
    $jb_conn = mysqli_connect( 'localhost', 'bambaya01', 'itbank', 'webdb' );
    $jb_sql = "SELECT username FROM member WHERE username = '$username';";
    $jb_result = mysqli_query( $jb_conn, $jb_sql );
    while ( $jb_row = mysqli_fetch_array( $jb_result ) ) {
      $username_e = $jb_row[ 'username' ];
    }
    if ( $username == $username_e ) {
      $wu = 1;
    } elseif ( $password != $password_confirm ) {
      $wp = 1;
    } else {
      $encrypted_password = password_hash( $password, PASSWORD_DEFAULT);
      $jb_sql_add_user = "INSERT INTO member ( username, password,name,phone,addr,Email ) VALUES ( '$username', '$encrypted_password', '$name', '$phone', '$addr', '$Email' );";
      mysqli_query( $jb_conn, $jb_sql_add_user );
      header( 'Location: ../main_auth.html' );
    }
  }
?>
      <?php
        if ( $wu == 1 ) {
          #echo "<p>사용자이름이 중복되었습니다.</p>";
          echo "<script>alert(\"사용자이름이 중복되었습니다.\");</script>";
	        echo "<script>location.replace('../main.html');</script>";
          exit;
        }
        if ( $wp == 1 ) {
          #echo "<p>비밀번호가 일치하지 않습니다.</p>";
          echo "<script>alert(\"비밀번호가 일치하지 않습니다.\");</script>";
          echo "<script>location.replace('../main.html');</script>";
           exit;
        }
      ?>